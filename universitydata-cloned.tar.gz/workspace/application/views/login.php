<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>UniversityData Signin</title>
	<link href="<?php echo base_url('assets/css/style.css');?>" rel="stylesheet">
</head>

<body>
  <hgroup>
  <h1>UniversityData</h1>
</hgroup>
<form>
  <div class="group">
    <input type="text"><span class="highlight"></span><span class="bar"></span>
    <label>Name</label>
  </div>
  <div class="group">
    <input type="email"><span class="highlight"></span><span class="bar"></span>
    <label>Email</label>
  </div>
  <a href="<?php echo site_url('Pages/home'); ?>"><button type="button" class="button buttonBlue">Sign in
    <div class="ripples buttonRipples"><span class="ripplesCircle"></span></div>
  </button></a>
</form>
  <script src="<?php echo base_url('assets/js/jquery.js');?>"></script>
  <script src="<?php echo base_url('assets/js/index.js');?>"></script>
</body>
</html>
