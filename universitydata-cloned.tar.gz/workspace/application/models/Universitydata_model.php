<?php
	class Universitydata_model extends CI_Model {

		public function __construct(){
			$this->load->database();					
		}
		
		public function getAllStudents() {
			$this->db->select('LastName');
			$this->db->select('FirstName');
			$this->db->select('BirthDate');
			$this->db->select('School');
			$this->db->from('students');
			return $query = $this->db->get()->result_array();        
		}
		
		public function getStudents($filter) {
			$this->db->select('LastName');
			$this->db->select('FirstName');
			$this->db->select('BirthDate');
			$this->db->select('School');
			$this->db->from('students');
			$this->db->where_in('School', $filter);
			return $query = $this->db->get()->result_array();        
		}
		public function getAllUniv() {
			$this->db->distinct();
			$this->db->select('School');
			$this->db->from('students');
			return $query = $this->db->get()->result_array(); 
		}
	}
?>