<?php
	class Pages extends CI_Controller {
		
		public function __construct(){
			parent::__construct();
			$this->load->model('Universitydata_model');
		}
		
		public function index()
		{
			$this->load->view('login');
		}
		public function home()
		{
			$selected = $this->input->post('selected');
			
			if($selected == "") {
				$students=$this->Universitydata_model->getAllStudents();	
			}
			else {
				$filter = explode(',', $selected);
				$students=$this->Universitydata_model->getStudents($filter);	
			}
			
			$univs=$this->Universitydata_model->getAllUniv();
			
			$data = array(
				'students' => $students,
				'univs' => $univs
			);
			
			$this->load->view('home', $data);
		}
	}

?>
