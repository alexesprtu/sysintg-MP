<?php
	class Pages extends CI_Controller {
		
		public function __construct(){
			parent::__construct();
			$this->load->model('Universitydata_model');
		}
		
		public function index()
		{
			$this->load->view('login');
		}
		public function check() {
			$usr = $this->input->post('username');
			$pwd = $this->input->post('password');
			
			$user=$this->Universitydata_model->checkUser($usr, $pwd);
			
			if (empty($user)) {
				$data = array(
					'alert' => "failed"
				);
				$this->load->view('login', $data);
			}
			else {
				$this->home();
			}
			
		}
		public function home()
		{
			$selected = $this->input->post('selected');
			$filter = array();
			
			if($selected == "") {
				$students=$this->Universitydata_model->getAllStudents();
				$univs=$this->Universitydata_model->getAllUniv();
			}
			else {
				$filter = explode(',', $selected);
				$students=$this->Universitydata_model->getStudents($filter);
				$univs=$this->Universitydata_model->getUniv($filter);
			}
			
			$allUnivs=$this->Universitydata_model->getAllUniv();
			
			$data = array(
				'students' => $students,
				'univs' => $univs,
				'allUnivs' => $allUnivs,
				'filter' => $filter
			);
			
			$this->load->view('home', $data);
		}
	}

?>
