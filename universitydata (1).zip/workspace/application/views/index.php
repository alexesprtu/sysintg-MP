<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>UniversityData Signin</title>
  
 <link rel="stylesheet" href="<?php echo base_url('assets/style.css'); ?>">
  
     

  
</head>

<body>
  <hgroup>
  <h1>UniversityData</h1>
</hgroup>
<form>
  <div id="lolxd" class="group">
    <input type="text"><span class="highlight"></span><span class="bar"></span>
    <label>Name</label>
  </div>
  <div class="group">
    <input type="email"><span class="highlight"></span><span class="bar"></span>
    <label>Email</label>
  </div>
  <button type="button" class="button buttonBlue">Sign in
    <div class="ripples buttonRipples"><span class="ripplesCircle"></span></div>
  </button>
</form>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="<?php echo base_url('assets/js/index.js'); ?>"></script>

</body>
</html>
